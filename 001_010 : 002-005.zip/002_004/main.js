/*Definir una clase persona de la cual tenga los siguientes atributos
nombre
edad
nacionalidad
altura
peso
enfermo

2 Definir la clase jugador que herede de personas y tenga los siguientes atributos
posicion(portero, defensa, medio, delantero)
numero

3) definir la clase entrenador que herede de persona y tenga los siguientes metodos
elegir plantila para equipo que elegira a sus jugadores para un partido
1 portero
4 defensas
4 medios
2 delanteros

4) definir la clase equio que tenga
array de jugardres
entrenador
un equipo tendra 22 jugadores
*/


var nombreJugadores = ["Memo", "Nestor", "Carlos", "Pedro", "Osvaldo", "Hector", "Hugo", "Marco", "Fabian", "Omar", "Juan"];
var nombrePosiciones=["Portero", "Defensa", "Medio", "Portero"];
var Equipo = function(nombre) {
    this.nombre=nombre;
    this.arrJugadores = [];
    this.entrenador = new Entrenador();
    for (var ju = 0; ju < 22; ju++) {
        this.arrJugadores.push(new Jugador());
    }
    //for (juEle = 0; juEle < this.arrJugadores.length; juEle++) {
    this.alineacion = this.entrenador.elegirPlantilla(this.arrJugadores);
    //}
}

/*var equipo1= new Equipo();
var equipo2= new Equipo();
*/
var Persona = function() {
    this._edad = getRandomInteger(20, 40);
    this._nacionalidad = "Mexicano";
    this._peso = getRandomInteger(60, 80);
    this._enfermo = false

}
Persona.prototype.iniPersona = function() {
    this._nombre = getNombre();
    this._enfermo= obtenEstadoSalud();

}

var Entrenador = function() {
    this.iniPersona()

    //this.elegirPlantilla()

}
Entrenador.prototype = new Persona();

//Se elige la plantilla de jugadores llamda desde la clase Equipo
Entrenador.prototype.elegirPlantilla = function(jugadoresElegidos) {
        var alineaEquipo = {
            portero: [],
            defensa: [],
            medio: [],
            delantero: []
        }
        for (je = 0; je < jugadoresElegidos.length; je++) {
            if (!alineaEquipo.portero.length) {
                alineaEquipo.portero.push(jugadoresElegidos[je]);
            } else {
                if (alineaEquipo.defensa.length < 4) {
                    alineaEquipo.defensa.push(jugadoresElegidos[je]);
                } else {
                    if (alineaEquipo.medio.length < 4) {
                        alineaEquipo.medio.push(jugadoresElegidos[je]);
                    } else {
                        if (alineaEquipo.delantero.length < 2) {
                            alineaEquipo.delantero.push(jugadoresElegidos[je]);
                        }
                    }
                }
            }
        }
        return alineaEquipo;
    }
    

var Jugador = function() {
    this.iniPersona();
    this._posicion = getPosicion();
    this._calidad = getRandomInteger(50, 100);
    this._numero = getRandomInteger(0, 100);
}
Jugador.prototype = new Persona();

var obtenEstadoSalud= function(){
    var virus=getRandomInteger(1,10)
        if(virus==10){
            return this._enfermo=true;
        }else
      return this._enfermo=false;
}

function getNombre() {
    var numeroAleatorio = Math.floor(Math.random() * nombreJugadores.length);
    return nombreJugadores[numeroAleatorio];
}

function getPosicion() {
    var numeroAleatorio = Math.floor(Math.random() * nombrePosiciones.length);
    return nombrePosiciones[numeroAleatorio];
}
//var jugador1 = new Jugador();

var equipo1 = new Equipo("Mexico");
var equipo2 = new Equipo("Resto del Mundo");

function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}


function Partido(equipo1, equipo2) {
    this.equipo1 = equipo1;
    this.equipo2= equipo2;
}


Partido.prototype.iniciaJuego = function(){
    console.log("inicia el Juego "+ this.equipo1.nombre + " VS " + this.equipo2.nombre );
    var ataque=0;
    while(ataque<10){
        ataque++;
    }
    
}


var partidoNuevo = new Partido(equipo1, equipo2);

partidoNuevo.iniciaJuego();
