/*Hacer funciones new y realizar una clase vikingo que almacene:

nombre
salud
potencia de ataque
velocidad

2) al realizar una funcion pelea que enfrente a dos vikingos y crearla con new

pelea tendra un metodo iniciarPelea que hara que empiecen


Una Pelea tendra una serie de asaltos en la que:

4> que los vikingos tenga un array de armas y que tengas una potencia clase Arma en el cual tiene:
Nombre:
tipo:
potencia (0/20)
ataques Restantes(0-10)
Subir el salud de vikingo a 100

5> agregar propedad armas a vikingo para que pueda hacer uso de ellas, agregar metodo addArma() para usarlas.

6> Modifica la funcion ataca Vikingo para que si no tiene armas ataque con la mas potente, cada ves que use una arma restara ataques restantes
Cuanto el arma tenga 0 en ataques restantes, tirara el arma (funcion abandonaArma) a vickingo 
*/

var Vickingo = function(nombre, salud, potenciaAtaque, velocidad) {
    this.nombre = nombre;
    this.salud = salud;
    this.potenciaAtaque = potenciaAtaque;
    this.velocidad = velocidad;
    this.armasVickingo = [];
    this.armaAtaque={};


}
Vickingo.prototype.atacaVickingo = function(vickingoAtacado) {
	console.log(this.armaAtaque.ataqueRestante)
	if(this.armaAtaque.ataqueRestante>0){
    vickingoAtacado.salud = vickingoAtacado.salud - this.armaAtaque.potencia;
}
};
Vickingo.prototype.addArma = function(armasDisponibles) {
    this.armas = armasDisponibles;

};
Vickingo.prototype.elijeArma = function(arma) {
    var armaElejida = null;
    //console.log(arma.length);
    for (var ar = 0; ar < arma.length; ar++) {
        if (!armaElejida) {
            armaElejida = arma[ar];
            this.armaAtaque=armaElejida;
        } else {
            if (arma[ar].potencia >= armaElejida.potencia) {
                armaElejida = arma[ar];
                this.armaAtaque=armaElejida;
            }
        }
    }

    console.log(armaElejida);
    return armaElejida;

};



var vickingo1 = new Vickingo("Pepe", 100, 20, 80);
var vickingo2 = new Vickingo("Toño", 200, 15, 100);

var Arma = function(nombre, tipo, potencia, ataqueRestante) {
    this.Nombre = nombre;
    this.tipo = tipo
    this.potencia = potencia;
    this.ataqueRestantes = ataqueRestante
}



var arma1Vik1 = new Arma("Shamehda", "Espada", 20, 10);
var arma2Vik1 = new Arma("Oxxo", "Hacha", 13, 10);
var arma3Vik1 = new Arma("Mzz", "Mazo", 10, 10);
var arma4Vik1 = new Arma("kuiji", "cuchillo", 1, 10);
var arma1Vik2 = new Arma("Shame", "Espada", 19, 9);
var arma2Vik2 = new Arma("Ox", "Hacha", 15, 9);
var arma3Vik2 = new Arma("Mzd", "Mazo", 10, 10);
var arma4Vik2 = new Arma("kunai", "cuchillo", 2, 5);

var arrArmasV1 = [arma1Vik1, arma2Vik1, arma3Vik1, arma4Vik1];
var arrArmasV2 = [arma1Vik2, arma2Vik2, arma3Vik2, arma4Vik2];

var Batalla = function(vik1, vik2) {
    this.vik1 = vik1;
    this.vik2 = vik2;

}
Batalla.prototype.iniciarPelea = function() {
    this.vik1.addArma(arrArmasV1);
    this.vik2.addArma(arrArmasV2);
    this.vik1.elijeArma(arrArmasV1);
   
    this.vik2.elijeArma(arrArmasV2);
    
    console.log("Pelearan de dos a tres Caidas " + this.vik1.nombre + " VS " + this.vik2.nombre);
    console.log(this.vik1.salud);
    while (this.vik1.salud > 0 && this.vik2.salud > 0) {
 console.log("Hola");


        if (this.vik1.velocidad > this.vik2.velocidad) {

            this.vik1.atacaVickingo(this.vik2);
           console.log("Hola");
            this.vik2.atacaVickingo(this.vik1);
            
        } else {
            this.vik2.atacaVickingo(this.vik1);
            
            this.vik1.atacaVickingo(this.vik2);
            
        }
    }

};

var pelea = new Batalla(vickingo1, vickingo2);

cicloBatalla = function() {
    pelea.iniciarPelea();
}



function abrirBatalla() {
    intervalID = setInterval(cicloBatalla, 1000);
}

function CerrarBatalla() {
    clearInterval(intervalID);
}
//abrirBatalla();
pelea.iniciarPelea();
