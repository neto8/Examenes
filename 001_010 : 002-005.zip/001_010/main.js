var zoo ={
    nombre:"El Zooooo",
    ubicacion:{},
    areas:[],
    aforos:[]
};

zoo.ubicacion={
	direccion:"Siempre Viva la vida",
	ciudad:"CDMX",
	pais:"MX"
};

function creaArea(nombreRecibido,aforoRecibido){
	var area={
		nombre:nombreRecibido,
		aforoMaximoZona:aforoRecibido,
		recintos:[]
	};
	return area;
}

/*var areaReptiles={
	nombre:"Reptiles",
	aforoMaximoZona:30,
	recintos:[]
};
var areaFelinos={
	nombre:"Felinos",
	aforoMaximoZona:10,
	recintos:[]
};
var areaAves={
	nombre:"Aves",
	aforoMaximoZona:20,
	recintos:[]
};
*/
var areaReptiles=creaArea("Reptiles",30);
var areaFelinos=creaArea("Felin",10);
var areaAves=creaArea("Aves",20);

jaulaSerpiente={
	Tipo:"Serpiente",
	animales:[]
};
jaulaLagarto={
	Tipo:"Lagarto",
	animales:[]
};
jaulaAguila={
	Tipo:"Aguila",
	animales:[]
};
jaulaHalcon={
	Tipo:"Halcon",
	animales:[]
};
jaulaLeon={
	Tipo:"Leon",
	animales:[]
};
jaulaLeopardo={
	Tipo:"Leopardo",
	animales:[]
};

animalMamba={
	nombre:"Seie",
	salud:"100",
	especie:"Mamba"
};
animalCobra={
	nombre:"ora",
	salud:"100",
	especie:"Cobra"
};

animalCaiman={
	nombre:"Caian",
	salud:"100",
	especie:"Caiman"
};
animalIguana={
	nombre:"Iua",
	salud:"100",
	especie:"Iguana"
};
zoo.areas.push(areaReptiles);
zoo.areas.push(areaFelinos);
zoo.areas.push(areaAves);
areaReptiles.recintos.push(jaulaSerpiente);
areaReptiles.recintos.push(jaulaLagarto);
areaAves.recintos.push(jaulaAguila);
areaAves.recintos.push(jaulaHalcon);
areaFelinos.recintos.push(jaulaLeon);
areaFelinos.recintos.push(jaulaLeopardo);
jaulaSerpiente.animales.push(animalMamba);
jaulaSerpiente.animales.push(animalCobra);
jaulaLagarto.animales.push(animalCaiman);
jaulaLagarto.animales.push(animalIguana);
console.log(zoo);
