/*

1) Haciendo uso de funciones y new, realiza una "clase" Vikingo que almacene la información de un vikingo:

nombre
salud (0 - 1000)
potenciaAtaque (1 - 20)
valocidad (0 - 100)

2) Haz uso de prototype y añade un método .ataca(vikingo) a un vikingo para que ataque a su oponente.
el ataque quitara salud al vikingo atacado (la potencia de ataque del atacante)

3) Realiza una clase Batalla() cuyas instancias enfrenten a dos vikingos.

Batalla tendrá un método iniciarPelea que hará de comienzo.

Una batalla tendrá una serie de asaltos en los que:

atacará primero el que más valocidad tenga,
y queitará de saludo su potencia de ataque al rival,
hasta que uno muera.

4) Crear la clase Arma() tenga un tipo: (espada/cuchillo...etc), una potencia (20 - 50) y un ataquesRestantes (0 -10).

5) Añade una propiedad armas a Vikingo para que pueda poseer varias armaspara su batalla.
Añade el método addArma() para añadir armas a los vikingos,

6) Modifica la función ataca del vikingo, para que si tiene armas disponibles ataque con el arma más potente.
Cada vez que se use un arma, debera restar uno a ataquesRestantes de ese arma.
Cuando el arma tenga 0 ataquesRestantes, el vikingo deberá abandonar el arma (añade la función abandonarArma al vikingo).

 */


// saludMaxima se usa como constante donde queramos usar la salud máxima (la bajé a 500 para que la batalla dure menos)
var saludMaxima = 500;
var nombresVickingos = ["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matías", "Vlairner", "Lucy", "Ignacio", "Humberto", "Néstor", "Daniel", "Raymundo", "Fran"];

function Ejercito() {
    this.arrVickingos = [];
    this.curanderos = [];
}

var Vikingo = function() {
    this._nombre = "";
    this._salud = 500;
}

//Al inicializarlo se genera nombre aleatorio
Vikingo.prototype.initVickingo = function() {
    this._nombre = generaNombreAleatorio();
}
//Crea Soldado
var SoldadoVickingo = function(potencia, velocidad) {
    //Inicializa Vikingo
    this.initVickingo();
    this._potencia = potencia;
    this._velocidad = velocidad;
    this.armas = [];
    this.armaElegida = null;

    //1-5 armas
}

//Se Hace la Herencia de vickingo hacia soldado Vickingo
SoldadoVickingo.prototype = new Vikingo();



//Genera nombres aleatorios de los solados y curanderos
function generaNombreAleatorio(){
 var numeroAleatorio = Math.floor(Math.random() * nombresVickingos.length);
    return nombresVickingos[numeroAleatorio];
}


//Se crea Curandero
var curanderoVickingo= function(){
    this.initVickingo();
    this.pocimas=5;
}


curanderoVickingo.prototype= new Vikingo();

curanderoVickingo.prototype.sanaVickingo= function(soldadoHerido){
    if(this.pocimas>0){
        soldadoHerido=soldadoHerido._salud=1000;
        this.pocimas=this.pocimas-1;
        console.log(soldado1._nombre);
    }else{
        console.log("Ya no puede curar");
    }
}




/* ********** Clase Vikingo ********** */
/*function Vikingo(nombre, tipo, salud, potencia, velocidad) {
    this.nombre = nombre;
    this.tipo=tipo;
    this.salud = salud;
    this.potenciaAtaque = potencia;
    this.velocidad = velocidad;
    this.armas = [];
    this.dinero = Math.floor(Math.random() * 1000) + 200;
    this.armaElegida = null;
}*/
Vikingo.prototype.ataca = function(vikingo) {
    var armaElegida = this.armaElegida || this.elegirArma();
    var potenciaAtaque = this.getPotenciaActual();
    var nombreArma = "sus puños";
    if (armaElegida) {
        armaElegida.usar();
        potenciaAtaque = armaElegida.potencia;
        nombreArma = armaElegida.tipo + "(" + armaElegida.ataquesRestantes + ")";
    }
    console.log(this._nombre + " atacará a " + vikingo._nombre + " con potencia " + potenciaAtaque + " usando " + nombreArma);
    vikingo.modificarSalud(-potenciaAtaque);
    if (armaElegida && armaElegida.ataquesRestantes === 0) {
        this.abandonarArma(armaElegida);
    }
};
SoldadoVickingo.prototype.getPotenciaActual = function() {
    var potenciaActual = Math.round(this._potencia * 0.8 + this._potencia * 0.2 * this._salud / saludMaxima);
    return potenciaActual;
};
SoldadoVickingo.prototype.modificarSalud = function(cantidad) {
    var soldado=this;
    this._salud += cantidad;
    if (this._salud < 0) {
        this._salud = 0;
        //sanaVickingo(soldado);
       // console.log("Entro a sanar");
        debugger;
    } else {
        if (this._salud > saludMaxima) {
            this._salud = saludMaxima;
        }
    }
    console.log("    La salud de " + this._nombre + " ahora es " + this._salud);
};
SoldadoVickingo.prototype.getEstado = function() {
    var estado = this._nombre + " [salud:" + this._salud + ", potencia:" + this._potencia + "(" + this.getPotenciaActual() + "), velocidad:" + this._velocidad + ", dinero:" + this.dinero + "]";
    for (var i = 0; i < this.armas.length; i++) {
        var arma = this.armas[i];
        estado += "\n    " + arma.tipo + " [potencia:" + arma.potencia + ", ataquesRestantes:" + arma.ataquesRestantes + "]";
    }
    return estado;
};

SoldadoVickingo.prototype.addArma = function(arma) {
    this.armas.push(arma);
};
SoldadoVickingo.prototype.abandonarArma = function(arma) {
    var indice = this.armas.indexOf(arma);
    var abandonadas = this.armas.splice(indice, 1);
    if (abandonadas[0] == this.armaElegida) {
        this.armaElegida = null;
    }
    console.log("    " + this._nombre + " ha abandonado su " + abandonadas[0].tipo);
};
SoldadoVickingo.prototype.elegirArma = function() {
    var armaElegida = null;
    for (var i = 0; i < this.armas.length; i++) {
        var arma = this.armas[i];
        if (!armaElegida || arma.potencia > armaElegida.potencia) {
            armaElegida = arma;
        }
    }
    if (armaElegida) {
        console.log("    " + this._nombre + " ha elegido su " + armaElegida.tipo);
        this.armaElegida = armaElegida;
    }
    return armaElegida;
};
SoldadoVickingo.prototype.robarDinero = function(vikingo) {
    this.dinero += vikingo.dinero;
    console.log(this._nombre + " ha robado " + vikingo.dinero + " monedas a " + vikingo._nombre);
    vikingo.dinero = 0;
};
SoldadoVickingo.prototype.robarArmas = function(vikingo) {
    if (vikingo.armas.length) {
        this.armas = this.armas.concat(vikingo.armas);
        console.log(this._nombre + " ha robado " + vikingo.armas.length + " armas a " + vikingo._nombre);
        vikingo.armas = [];
    }
};


/* ********** Clase Batalla ********** */
function Batalla(vikingo1, vikingo2) {
    this.vikingos = [vikingo1, vikingo2];
}
Batalla.prototype.iniciarPelea = function() {
    console.log("***** " + this.vikingos[0]._nombre + " y " + this.vikingos[1]._nombre + " entraran en batalla *****");
    console.log(this.vikingos[0].getEstado());
    console.log(this.vikingos[1].getEstado());

    var v1 = this.vikingos[0]._velocidad;
    var v2 = this.vikingos[1]._velocidad;
    var turno = v1 > v2 ? 0 : v1 < v2 ? 1 : Math.round(Math.random());

    var atacante;
    var atacado;

    while (this.vikingos[0]._salud > 0 && this.vikingos[1]._salud > 0) {
        
        atacante = this.vikingos[turno];
        atacado = this.vikingos[turno ? 0 : 1];
        atacante.ataca(atacado);
        turno = turno ? 0 : 1;
        //debugger;
    }

    console.log("***** " + atacante._nombre + " ha ganado la batalla contra " + atacado._nombre + " *****");
    //atacante.robarDinero(atacado);
    //atacante.robarArmas(atacado);
    console.log(this.vikingos[0].getEstado());
    console.log(this.vikingos[1].getEstado());
};


/* ********** Clase Arma ********** */
function Arma(tipo, potencia, ataquesRestantes) {
    this.tipo = tipo;
    this.potencia = potencia;
    this.ataquesRestantes = ataquesRestantes;
}
Arma.prototype.usar = function() {
    this.ataquesRestantes--;
};



/* ********** Declaramos los vikingos y sus armas ********** */

//Se hereda propiedades de Vickingo hacia Curandero Vickingo

var ejercito1 = new Ejercito();
var ejercito2 = new Ejercito();

//Se generan los 5 curanderos
for(var cura=0; cura<5; cura++){
    ejercito1.curanderos.push(new curanderoVickingo());
    ejercito2.curanderos.push(new curanderoVickingo());
}

for(var sol=0; sol<25; sol++){
    ejercito1.arrVickingos.push(new SoldadoVickingo());
    ejercito2.arrVickingos.push(new SoldadoVickingo());
}

/*var Arma = function(nombre, tipo, potencia, ataqueRestante) {
    this.Nombre = nombre;
    this.tipo = tipo
    this.potencia = potencia;
    this.ataqueRestantes = ataqueRestante
}*/



var arma1Vik1 = new Arma("Espada", 20, 10);
var arma2Vik1 = new Arma("Hacha", 13, 10);
var arma3Vik1 = new Arma("Mazo", 10, 10);
var arma4Vik1 = new Arma("cuchillo", 1, 10);
var arma1Vik2 = new Arma("Espada", 19, 9);
var arma2Vik2 = new Arma("Hacha", 15, 9);
var arma3Vik2 = new Arma("Mazo", 10, 10);
var arma4Vik2 = new Arma("cuchillo", 2, 5);

var arrArmasV1 = [arma1Vik1, arma2Vik1, arma3Vik1, arma4Vik1];
var arrArmasV2 = [arma1Vik2, arma2Vik2, arma3Vik2, arma4Vik2];
/*curandero1= new curanderoVickingo();
curandero2= new curanderoVickingo();
curandero3= new curanderoVickingo();
curandero4= new curanderoVickingo();
curandero5= new curanderoVickingo();*/
// var =[curandero1,curandero2,curandero3,curandero4,curandero5 ]
// var flotaCuranderos= new Ejercito();

// var erik = new SoldadoVickingo(18, 50);
// soldado1 = new SoldadoVickingo(15, 10);
// soldado2 = new SoldadoVickingo(15, 10);
// soldado3 = new SoldadoVickingo(15, 10);
// soldado4 = new SoldadoVickingo(15, 10);
// soldado5 = new SoldadoVickingo(15, 10);
// var flotaSoldados=[soldado1,soldado2,soldado3,soldado4,soldado5]
// erik.addArma(new Arma("maza", 40, 5));
// erik.addArma(new Arma("hacha", 45, 5));
// erik.addArma(new Arma("espada", 33, 10));

// flotaCuranderos
// var olaf = new SoldadoVickingo(20, 50);
// olaf.addArma(new Arma("espada", 35, 8));
// olaf.addArma(new Arma("hacha", 42, 8));
// olaf.addArma(new Arma("cuchillo", 24, 10));


/* ********** Inicia la batalla ********** */

//var batalla = new Batalla(erik, olaf);

//batalla.iniciarPelea();
