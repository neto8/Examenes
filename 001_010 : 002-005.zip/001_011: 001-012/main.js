
var nombresPersonas=["Victor", "Omar", "Karen", "Ariel", "Omar", "David", "Esteban", "Matias","Vlariner", "Lucy", "Ignacio", "Humberto", "Nestor", "Daniel", "Ray", "Fran"];
var zoo = {
	nombre: "El último zoológico",
	ubicacion: {},
	areas: [],
	aforo: 1,
	NumeroVisitantes:0,
	caja:1000000,
	enfermeria:[]
};


//zoo.push(enfermeria);
var ubicacion = {
	dirreccion: "Calle de los animalitos 123",
	ciudad: "Ciudad de México",
	pais: "México",
	telefono: 999888777
}

function area(nombre, aforo, recintos, animales){
	return {
		nombre: nombre,
		aforoMaximo: aforo,
		recintos: recintos,
	};
}

function recintoDetalles(nombre, animales, capacidad, detalle){
	return {
		nombre: nombre,
		animales: animales,
		capacidad: capacidad,
		detalle: detalle,
		visitantes:[]
	};
}

function animales(nombre, especie, salud, hambre, pais){
	return {
		nombre: nombre,
		especie: especie,
		salud: salud,
		hambre: hambre,
		pais: pais
	};
}

var tigreBlanco = animales("Tigre Blanco", "Felino", 100, 80, "Egipto");
var tigreNormal = animales("Tigre", "Felino", 100, 60, "Africa");

var palomas = animales("Palomas", "Avis Chilensis", 100, 100, "Chile");
var flamencos = animales("Flamenco", "Phoenicopteridae", 100, 0, "Colombia");

var tigres = [];
tigres.push(tigreBlanco, tigreNormal);

var aves = [];
aves.push(palomas, flamencos);

var recinto1 = recintoDetalles("Jaula de tigres", tigres, 1200, "Jaula super reforzada con titanium");
var recinto2 = recintoDetalles("Baños", [], 100, "Baños para hombres y mujeres, aptos para personas con discapacidad");
var recinto3 = recintoDetalles("Jaula para aves", aves, 100, "Algunas aves que se pelean a seguido");

var recintoTigres = [];
recintoTigres.push(recinto1, recinto2);

var recintoAves = [];
recintoAves.push(recinto3);

var area1 = area("Mamíferos", 5000, recintoTigres);
var area2 = area("Aves", 200, recintoAves);

zoo.ubicacion = ubicacion;
zoo.areas.push(area1, area2);


//representa el paso de 1 hora en el ZOO
function ejecutaCiclo(){
//Añade Personas
		addPersona();
		console.log("Se agrego una persona");
		//curarAnimalesEnfermeria();
}
function cerrarZoo(){

}
function curarAnimalesEnfermeria(){
	var animalcurado={};
	var saludAnimalCurando={};
	for(var anc=0; anc < zoo.enfermeria.length ; anc++){
		saludAnimalCurando=zoo.enfermeria[anc].animal.salud
		if(saludAnimalCurando==100){
			for(var ar=0; ar < zoo.areas.length; ar++){
		
				for (var re=0; re < zoo.areas[ar].recintos.length; re++){
					if(zoo.areas[ar].recintos[re].nombre==zoo.enfermeria[anc].recinto.nombre){
						zoo.areas[ar].recintos[re].animales.push(zoo.enfermeria[anc].animal)
						delete zoo.enfermeria[anc]
					}
					
				}
			}
			zoo.enfermeria[anc].recinto.nombre
		}else{
			zoo.enfermeria[anc].animal.salud=saludAnimalCurando+10;
			console.log(zoo.enfermeria[anc].animal.nombre);
		}
	}
}
function recoreTodosAnimales(){
	var arregloAnimales={};
	var animalPocaSalud=[]
	var recintoAnimal={};
	for(var ar=0; ar < zoo.areas.length; ar++){
		
		for (var re=0; re < zoo.areas[ar].recintos.length; re++){
			
			for(var an=0; an < zoo.areas[ar].recintos[re].animales.length ; an++){
				//arregloAnimales.push(zoo.areas[ar].recintos[re].animales[an]);
				animalPocaSalud=zoo.areas[ar].recintos[re].animales
				arregloAnimales=zoo.areas[ar].recintos[re].animales[an];
				recintoAnimal=zoo.areas[ar].recintos[re];
				modificarSaludAleatoria(arregloAnimales,zoo.areas[ar].recintos[re])
				
				if(arregloAnimales.salud<50){
					enEnfermeria(arregloAnimales,recintoAnimal);
					console.log(animalPocaSalud[an]);
					animalPocaSalud.splice(an,1);
				}
			}
		}
	}
	
	
}

function generaNombreAleatorio(){
	var numeroAleatorio= Math.floor(Math.random()* nombresPersonas.length);
	return nombresPersonas[numeroAleatorio];
}
 function generaEdad(){
 	var edadAleatorio= Math.floor(Math.random()*100);
	return edadAleatorio;
 }
function generaEstudioAleatorio(){
 	var esEstudiante= Math.round(Math.random());
	return esEstudiante;
 }
function addPersona(){
	if (zoo.NumeroVisitantes<zoo.aforo){
		var persona=creaPersona(generaNombreAleatorio(),500,generaEdad(), generaEstudioAleatorio());
		cobraEntrada(persona);
		var recintoLibre=primerRecintoLibre();
		recintoLibre.visitantes.push(persona);
		zoo.NumeroVisitantes++;		
	}else{
		console.log("ya no hay espacio Adios!!");
		clearInterval(intervalID);
		zoo.NumeroVisitantes=0;
		console.log("Largo Todos" + zoo.NumeroVisitantes)
	}
}

function primerRecintoLibre(){
	recintoLibre=null;
	for(var a=0; a<zoo.areas.length; a++){
		var area= zoo.areas[a];
		for(var r=0; r<area.recintos.length;r++){
			var recinto=area.recintos[r];
				if(!recintoLibre && recinto.visitantes.length<recinto.capacidad){
					recintoLibre=recinto;
				}
		}
	}
	return recintoLibre;
}

function cobraEntrada(persona){
	var importeEntrada=5;
	if(persona.edad<14 || persona.edad>65){
		importeEntrada=0;
	}else{
		if(persona.estudiante){
			importeEntrada=3;
		}
	}
	persona.cartera=persona.cartera-importeEntrada;
	zoo.caja=zoo.caja+importeEntrada;
}

function creaPersona(nombrePersona, carteraPersona, edadPersona, estudiaPersona){
	var persona={
		nombre:nombrePersona,
		cartera:carteraPersona,
		edad:edadPersona,
		estudiante:estudiaPersona
	};
	return persona;
}
function enEnfermeria(animalEnfermo, recintoAnimalEnfermo){
var caso = {
	animal:animalEnfermo,
	recinto:recintoAnimalEnfermo
}

zoo.enfermeria.push(caso);
//recintoAnimalCurando.push(recintoAnimalEnfermo);
console.log("Entra a enfermeria "+ animalEnfermo.nombre)
}

function modificarSaludAleatoria(animalRec,recintoRec){
	var saludAnimal;
	if(animalRec.salud<50){
		
	}else{
		if (Math.round(Math.random()*1)==0){
	   		animalRec.salud=animalRec.salud-20;
	   		console.log(animalRec.salud);
	   		console.log(animalRec.nombre);
		}else{
			if(animalRec.salud < 79){
				animalRec.salud=animalRec.salud+20;
				console.log(animalRec.salud);
				console.log(animalRec.nombre);
			}
		}
	}
	//return salud;
}

var intervalID= setInterval(ejecutaCiclo,1000);

console.log(zoo);