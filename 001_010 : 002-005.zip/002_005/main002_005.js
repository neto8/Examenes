/*
1) Realiza la modelización de un parque natural. Empieza con el siguiente código.

var parqueNatural = {
areas = [],
parqueDeBomberos = {}
}

En cada una de las áreas (añade 10 áreas) encontraremos un array de árboles (100 por área) y un array de visitantes (100 en todo el parque).
En el parque de bomberos encontraremos un array de bomberos (10) y posiblemente más propiedades que se te puedan ocurrir.
Los bomberos y los visitantes deberán heredar de la clase Persona.

2) Añade un método ejecutar ciclo que represente el paso de 1h en el parque.
Cada ciclo que pase debemos llamar a ejecutar ciclo de los visitantes que se irán cambiando de recinto de forma aleatoria.
Haz que el método se ejecute cada segundo.

3) En cada paso de un ciclo se puede originar un fuego (probabilidad del 5%) que empezaría quemando un arbol aleatorio dentro del parque.
Cada ciclo que pase el fuego se extenderá al arbol al arbol siguiente, si no hay arbol siguiente, deberá saltar al primer arbol del área siguiente.
Asi sucesivamente hasta expandirse por todo el parque. Cada ciclo que pase el fuego en los arboles, estos estarán un 10% más quemados.
Cuando lleguen al 100% de quemados, se habrá perdido el arbol. (Quitarlo del área).​

*/

var parqueNatural = function() {

    this._parqueBomberos = { arrayBomberos: [] };
    this._visitantes = [];
    this._areas = [];

    for (numVis = 0; numVis < 100; numVis++) {
        this._visitantes.push(new Visitante(numVis));
    }

    for (numArea = 0; numArea < 10; numArea++) {
        this._areas.push(new Area(numArea));
    }

    for (arB = 0; arB < 10; arB++) {

        this._parqueBomberos.arrayBomberos.push(new Bombero(arB));
    }
}

var Area = function(idArea) {
    this._idArea = idArea;
    this._arrArboles = [];
    for (numArbol = 0; numArbol < 100; numArbol++) {
        this._arrArboles.push(new Arbol(numArbol));
    }
    this._visitantesArea = [];
    this._arrArbolesQuemados = [];

}

var Arbol = function(idArbol) {
    this._idArbol = idArbol;
    this._salud = 100;
    this._estadoEncendido = false;
}

var Persona = function() {
    this._nombre = "";
}

var Visitante = function(NumeroVisitante) {
    this._idVisitante = NumeroVisitante;
}
var Bombero = function(idBom) {
    this._idBombero = idBom;
}


Visitante.prototype = new Persona();
Bombero.prototype = new Persona();

parqueMexico = new parqueNatural();


//Crea prototipo de Parque con Agrega Visitantes 
parqueNatural.prototype.addVisitantes = function(visitante) {
    var areasConVisitantes = 0;
    for (var visAr = 0; visAr < visitante.length; visAr++) {
        areasConVisitantes = buscarArea(this._areas);
        //se va agregando los visitantes a cada Area
        this._areas[areasConVisitantes]._visitantesArea.push(visitante[visAr]);
    }
}

parqueNatural.prototype.quemaArboles = function() {
    var proQuema = generaNumeroAleatorio(0, 20);
    var estadoSalud = 0;
    var areaAleatoria = generaNumeroAleatorio(0, this._areas.length - 1);
    var arbolAleatorio = generaNumeroAleatorio(0, 100);

    for (var areaQ = 0; areaQ < this._areas.length; areaQ++) {
        
        for (var arbol in this._areas[areaQ]._arrArboles) {
            if (this._areas[areaQ]._arrArboles[arbol]._estadoEncendido == true) {

                //quema los arboles del lado
                var arbolIzq = arbol - 1;
                var areaIzq= areaQ-1;
                
                if (this._areas[areaQ]._arrArboles[arbolIzq]._estadoEncendido == false) {
                    this._areas[areaQ]._arrArbolesQuemados.push(this._areas[areaQ]._arrArboles[arbolIzq]);
                }if (this._areas[areaQ]._arrArboles[arbol]._salud<=0){
                    console.log("Borrando "+ this._areas[areaQ]._arrArboles[arbol]._idArbol);
                    delete this._areas[areaQ]._arrArboles[arbol];
                }
                this._areas[areaQ]._arrArboles[arbolIzq]._salud = this._areas[areaQ]._arrArboles[arbolIzq]._salud - 20;
                this._areas[areaQ]._arrArboles[arbolIzq]._estadoEncendido = true;
                
                //console.log(this._areas[areaQ]._arrArboles[arbol]);
                
            }
            // }
        }
        this._areas[areaQ].imprimirEstadoArea(areaQ);

    }
    //this.propagaIncendio();

    if (proQuema == 1) {
        this._areas[areaAleatoria]._arrArboles[arbolAleatorio]._salud = this._areas[areaAleatoria]._arrArboles[arbolAleatorio]._salud - 10;
        this._areas[areaAleatoria]._arrArboles[arbolAleatorio]._estadoEncendido = true;
        this._areas[areaAleatoria]._arrArbolesQuemados.push(this._areas[areaAleatoria]._arrArboles[arbolAleatorio])
        console.log(this._areas[areaAleatoria]._arrArboles[arbolAleatorio]);
        console.log(this._areas[areaAleatoria]._idArea);
    } else {
        console.log("No se quemo ninguno ahora");
    }

}

parqueNatural.prototype.propagaIncendio = function(area) {
    this._areas[areaAleatoria]._arrArbolesQuemados.length;
    // for (var areaQuema = 0; areaQuema < this._areas.length; areaQuema++) {

    //         for (var quema = 0; quema < this._areas[areaQuema]._arrArbolesQuemados.length; quema++) {
    //             //this._areas[areaQuema]._arrArboles[quema-1]._salud = this._areas[areaQuema]._arrArboles[quema + 1]._salud - 10;
    //             this._areas[areaQuema]._arrArboles[quema - 1]._estadoEncendido = true;
    //             this._areas[areaQuema]._arrArbolesQuemados.push(this._areas[areaQuema]._arrArboles[quema-1])

    //             console.log("Area quemada " + areaQuema);
    //             console.log("Arbol Quemado " + this._areas[areaQuema]._arrArbolesQuemados[quema]._idArbol)
    //         }
    //     }
}


// se manda a llamar Visitantes con el arreglo de visitantes ya lleno al inicio

parqueMexico.addVisitantes(parqueMexico._visitantes);



function buscarArea(areaBuscada) {
    var areasTotales = (areaBuscada.length) - 1;
    var aleatoria = generaNumeroAleatorio(0, areasTotales);

    while (areaBuscada[aleatoria]._visitantesArea.length > 9) {
        aleatoria = generaNumeroAleatorio(0, areasTotales);
    }
    return aleatoria;
}


function cicloParque() {
    parqueMexico.quemaArboles();
    console.log("---------entra a Ciclo-----------");
}

var timeOutId = setInterval(cicloParque, 1000);

var terminaCiclo = function() {
    clearInterval(timeOutId);
}


function generaNumeroAleatorio(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

Area.prototype.imprimirEstadoArea = function(areaQuemada) {
    var estadoArea = "";
    for (var i = 0; i < this._arrArboles.length; i++) {
        var estadoArbol = "i";
        if (this._arrArboles[i]._estadoEncendido==true) {
            estadoArbol = "X";
        }
        estadoArea = estadoArea + estadoArbol;
    }
    console.log("Estado del área " + this._idArea);
    console.log("======================");
    console.log(estadoArea);
    console.log("======================");
}


cicloParque();
